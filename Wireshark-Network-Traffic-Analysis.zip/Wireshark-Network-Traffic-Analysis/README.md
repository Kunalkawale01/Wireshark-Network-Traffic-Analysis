# 🧠 Task 5: Capture and Analyze Network Traffic Using Wireshark

## 🎯 Objective
Capture live network packets and identify basic protocols and traffic types using Wireshark.

---

## 🧩 Tools Used
- **Wireshark**
- **Operating System:** Windows / Linux
- **Protocols Observed:** DNS, HTTP, ICMP, TCP, UDP

---

## ⚙️ Steps Performed
1. Installed Wireshark and started capture on the active network interface.
2. Generated traffic by browsing websites and pinging servers.
3. Stopped capture and saved it as `network_capture.pcap`.
4. Analyzed packets using protocol filters like DNS, HTTP, and ICMP.

---

## 🔍 Protocols Identified

| Protocol | Description | Example |
|-----------|--------------|----------|
| **DNS** | Resolves domain names into IP addresses. | Query: `A www.google.com` |
| **HTTP** | Web traffic for browsing sites. | GET request to `wikipedia.org` |
| **ICMP** | Used for ping operations. | Echo request/reply to `8.8.8.8` |
| **TCP** | Reliable connection protocol. | SYN/ACK handshake |
| **UDP** | Connectionless data transfer. | DNS queries over UDP 53 |

---

## 📈 Observations
- DNS queries occur before HTTP requests.
- TCP three-way handshake observed.
- ICMP packets seen during ping.
- Mix of UDP (DNS) and TCP (HTTP) traffic.

---

## 📚 Outcome
Hands-on experience in:
- Packet capturing with Wireshark  
- Protocol identification  
- Network traffic analysis  

**Result:** Improved understanding of TCP/IP communication and protocol behavior.
